<?php 
$login =false;
$showerr=false;
if($_SERVER['REQUEST_METHOD'] == "POST"){
  include("connect.php");
  $username=$_POST["username"];
  $password=$_POST["password"];
  
  // $sql="SELECT * FROM `users` WHERE username='$username' AND password='$password'";
  $sql="SELECT * FROM `users` WHERE username='$username' ";
  $result = mysqli_query($conn,$sql);
  $num = mysqli_num_rows($result);
  if($num== 1){
    while($row= mysqli_fetch_assoc($result)){
      if(password_verify($password,$row['password'])){
        $login=true;
        session_start();
        $_SESSION['loggedin']=true;
        $_SESSION['username']=$username;
        header ("location: welcome.php");

      }else{
        $showerr="invalid";
      }
      
    }
    
  }else{
    $showerr="invalid";
  }
} 

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <title>login</title>
</head>
<body>
  <?php require("_nav.php"); ?>
  <div class="container my-4">
    <?php
    if($login){
      echo'<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success</strong> You account  login.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>';
    }
    if($showerr){
      echo'<div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> '.$showerr.'.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>';
    }
    ?>    
    <h1 class="text-center">login our website</h1>
    
    <form action="" method="post">
      <div class="form-group  col-md-6">
        <label for="username">Username</label>
        <input type="text" class="form-control" id="username " name="username" >
      </div>
      <div class="form-group col-md-6">
        <label for="password">Password</label>
        <input type="password" class="form-control" id="password" name="password">
      </div>
      
      
      <button type="submit " class="btn btn-primary align-center">login</button>
  </form>
  </div>
  
</body>
</html>