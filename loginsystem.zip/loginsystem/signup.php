<?php 
$showAlart =false;
$showerr=false;
if($_SERVER['REQUEST_METHOD']=="POST"){
  include("connect.php");
  $username=$_POST['username'];
  $password=$_POST['password'];
  $password1=$_POST['password1'];
  // $exits = false;
  $existSql = "SELECT * FROM `users` WHERE username='$username'";
  $result=mysqli_query($conn,$existSql);
  $numExistRow = mysqli_num_rows($result);

  if($numExistRow>0){
    $showerr = "Username already Exist";
  }else{
    if($password==$password1){
      $hash = password_hash($password, PASSWORD_DEFAULT);
      $sql="INSERT INTO `users`( `username`, `password`, `dt`) VALUES ('$username','$hash',current_timestamp())";
      $result = mysqli_query($conn,$sql);
      if($result){
        
        $showAlart=true;
      }
  
    }else{
      $showerr="Password do not match";
    }
  }
} 

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <title>SIgnuP</title>
</head>
<body>
  <?php require("_nav.php"); ?>
  <div class="container my-4">
    <?php
    if($showAlart){
      echo'<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success</strong> You account now created and you can login.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>';
    }
    if($showerr){
      echo'<div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> '.$showerr.'.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>';
    }
    ?>    
    <h1 class="text-center">SignUp our website</h1>
    
    <form action="" method="post">
      <div class="form-group  col-md-6">
        <label for="username">Username</label>
        <input type="text" maxlength="11" class="form-control" id="username " name="username" >
      </div>
      <div class="form-group col-md-6">
        <label for="password">Password</label>
        <input type="password" maxlength="23" class="form-control" id="password" name="password">
      </div>
      <div class="form-group col-md-6">
        <label for="password1">Confirm Password</label>
        <input type="password" class="form-control" id="cpassword" name="password1">
        <small>make sure to type the same password</small>
      </div>
      
      <button type="submit " class="btn btn-primary align-center">Signup</button>
  </form>
  </div>
  
</body>
</html>